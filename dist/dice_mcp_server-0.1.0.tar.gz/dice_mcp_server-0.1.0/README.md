# dice-mcp-server

# 🎲 Dice MCP Server

![Dice MCP Server](assets/dice_mcp_server_header.svg)

## 📖 概要
このプロジェクトは、6面サイコロを振るためのシンプルなMCPサーバーです。

## 🚀 インストール
以下のコマンドでインストールできます:
pip install dice-mcp-server


## 🛠️ 使い方
サイコロを振るには、以下のコマンドを実行してください:
dice-mcp-server


## 📜 ライセンス
このプロジェクトはMITライセンスの下で提供されています。